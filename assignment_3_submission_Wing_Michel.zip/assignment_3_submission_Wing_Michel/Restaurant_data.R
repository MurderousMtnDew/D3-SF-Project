require(dplyr)
restaurant_scores <- read.csv("restaurant_score_original.csv")

#Convert the score, any blanks, to "NA" to make the score column numeric. That's how to calculate the low, median, and high. After, convert the score back to a string and convert any NA's to "No score"
inspection_categ <- cut(restaurant_scores$inspection_score, breaks = c(100,85,70,50), labels=c('Low Score', 'Mid-Level Score', 'High Score'))
data.frame(restaurant_scores$inspection_score, inspection_categ)

restaurant_scoresx <- mutate(restaurant_scores, inspection_categ)

View(restaurant_scoresx)
restaurant_scores <- restaurant_scoresx[c(2,3,5,6,11,15)]

View(restaurant_scores)

write.csv(restaurant_scores, file = "restaurant_score.csv")

high_scores <- filter(restaurant_scores, inspection_categ=="High Score")
write.csv(high_scores, file = "high_score.csv")

med_scores <- filter(restaurant_scores, inspection_categ=="Mid-Level Score")
write.csv(med_scores, file = "mid_score.csv")

low_scores <- filter(restaurant_scores, inspection_categ=="Low Score")
write.csv(low_scores, file = "low_score.csv")
